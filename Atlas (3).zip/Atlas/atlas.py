# -*- coding: utf-8 -*-
"""
/***************************************************************************
 Atlas
                                 A QGIS plugin
 This plugin produces map layers from poverty profile data for KC-NCDDP municipalities.
                              -------------------
        begin                : 2016-07-22
        git sha              : $Format:%H$
        copyright            : (C) 2016 by Kimberley Coles/University of Redlands/KC-NCDDP
        email                : kimberley_coles@redlands.edu
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""
from PyQt4.QtCore import QSettings, QTranslator, qVersion, QCoreApplication
from PyQt4.QtGui import QAction, QIcon, QFileDialog
# Initialize Qt resources from file resources.py
import resources
# Import the code for the dialog
from atlas_dialog import AtlasDialog
import os.path

from qgis.core import *
from qgis.gui import *
from qgis.utils import *
from PyQt4.QtCore import *
from PyQt4.QtGui import *
from PyQt4.QtXml import *
import csv
import xlrd
import sys


global muniDict 
muniDict = {}

global indicators
#use smaller number of two for testing
indicators = (
        "health", "composite")
#indicators = (
  #      "health","nutrition","access","shelter","income","education", "labor", "composite")

def find_muniNumber(clpiTuple, muniName):
    for bar in clpiTuple:
        print bar
    return muniPSGC


def remove_duplicates(l):
    return list(set(l))
    
def createCLPI (PIMSFileLocation):
    #function takes a PIMS csv file and creates two CLPI csv files: raw and clpi
    #raw has the 14 individual indicators
    #clpi has the consolidated 7 measures plus a composite (8)
   
    #In Sept 2016 it was decided to remove labor and income measures and associated indicators
    #thus there are currently 5 indicators and 10 measures
    
   # supply path to qgis install location
    QgsApplication.setPrefixPath(u'C:/PROGRA~1/QGISWI~1/apps/qgis', True)

    print "Opening PIMS csv file: ", PIMSFileLocation
    QgsMessageLog.logMessage("Opening PIMS csv file:")
    number_measures = 10
    number_indicators = 5
    
    
    with open (PIMSFileLocation, 'rb') as xclfile:
        reader = csv.reader (xclfile)
        header_row = 0
        rawTuple = []
        clpiTuple = []
        totalrows = 0
        
        # ORIGINAL WITH INCOME, LABOR, and COMPOSITE
        # clpiHeader = ["Brgy_PSGC", "brgName", "muniName","muniPSGC", "cycle", "year", "numHH", "numIPHH", "numPPHH", 
           # "numSLPHH", "health", "nutrition", "access", "shelter", "income", "education", "labor", "composite", "numNulls"]
        # rawHeader = ["Brgy_PSGC", "brgName", "muniName","muniPSGC", "cycle", "year", "numHH", "numIPHH", "numPPHH", 
           # "numSLPHH", "clpi1", "clpi2", "clpi3", "clpi4", "clpi5", "clpi6", "clpi7", "clpi8", "clpi9", "clpi10", "clpi11", "clpi12", "clpi13", 
            # "clpi14", "numNulls"]
            
        
        # REVISION removed income, labor, and composite measures and the indicators used within them: CLPI 9, 10, 11, and 14
        clpiHeader = ["Brgy_PSGC", "brgName", "muniName","muniPSGC", "cycle", "year", "numHH", "numIPHH", "numPPHH", 
           "numSLPHH", "health", "nutrition", "access", "shelter", "education", "numNulls"]
        rawHeader = ["Brgy_PSGC", "brgName", "muniName","muniPSGC", "cycle", "year", "numHH", "numIPH10", "numPPHH", 
           "numSLPHH", "clpi1", "clpi2", "clpi3", "clpi4", "clpi5", "clpi6", "clpi7", "clpi8", "clpi12", "clpi13", "numNulls"]
            
            
        clpiTuple.append (clpiHeader)
        rawTuple.append (rawHeader)
            
        for row in reader:
            #print ', '.join(row)
            if header_row == 0:
                fields = row
                header_row = 1
            else:
                header_row = 1
                numnulls=0
                numerrors=0
                barangayRow_Raw = []
                barangayRow_CLPI = []

                #identifying information
                barangayPSGC = str(row [5])
            
                if len(barangayPSGC) == 8:
                    barangayPSGC = '0'+ barangayPSGC
               
                barangayRow_Raw.append (barangayPSGC)
                barangayRow_CLPI.append (barangayPSGC)
                #print barangayPSGC

                #barangayName = str (row[4])
                barangayName = row[4]
                barangayRow_Raw.append (barangayName)
                barangayRow_CLPI.append (barangayName)

                #muniName = str(row[3])
                muniName = row[3]
                barangayRow_Raw.append (muniName)
                barangayRow_CLPI.append (muniName)

                muniPSGC = str(barangayPSGC[0:6])+"000"
                barangayRow_Raw.append (muniPSGC)
                barangayRow_CLPI.append (muniPSGC)

                cycle = str(row[7])
                barangayRow_Raw.append (cycle)
                barangayRow_CLPI.append (cycle)

                yrDataSourced = int(row[9])
                barangayRow_Raw.append (yrDataSourced)
                barangayRow_CLPI.append (yrDataSourced)

                #Get demographics
                numHouseholds = int(row[10])
                barangayRow_Raw.append (numHouseholds)
                barangayRow_CLPI.append (numHouseholds)

                numIPHouseholds = int(row[12])
                barangayRow_Raw.append (numIPHouseholds)
                barangayRow_CLPI.append (numIPHouseholds)

                numPantawidHouseholds = int(row[29])
                barangayRow_Raw.append (numPantawidHouseholds)
                barangayRow_CLPI.append (numPantawidHouseholds)

                numSLPHouseholds = int(row[31])
                barangayRow_Raw.append (numSLPHouseholds)
                barangayRow_CLPI.append (numSLPHouseholds)

                #make municipal name, number dictionary
                muniDict [muniPSGC] = muniName
                
                #calculate Health Index
                #check for nulls
                count = 0
                if row[146] == None or row[148] == None or not row [146] or not row[148]:
                        clpi1 = 0
                        numnulls +=1
                else:
                    childdeath = float(row[146])
                    clpidem = float (row[148])
                     #check for 0 in denominator, so as to avoid dividing by 0
                    if clpidem == 0:
                        clpi1 = 0
                        numnulls +=1
                    else:
                        clpi1 = (childdeath/clpidem)*100
                        if clpi1 >100 or clpi1 < 0:
                            clpi1 = 0
                        else:
                            count +=1

                if row[150] == None or row[152] == None or not row [150] or not row[152]:
                    clpi2 = 0
                    numnulls +=1
                else:
                    maternaldeath = float(row[150])
                    clpidem2 = float (row[152])
                    #check for 0 in denominator, so as to avoid dividing by 0
                    if clpidem2 == 0:
                        clpi2 = 0
                        numnulls +=1
                    else:
                        clpi2= (maternaldeath/clpidem2)*100
                        if clpi2 >100 or clpi2 < 0:
                            clpi2 = 0
                        else:
                             count +=1
                
                if count == 0:
                    health = 0
                else:
                    health = round((clpi1 + clpi2)/count, 2)
               
                barangayRow_Raw.append (clpi1)
                barangayRow_Raw.append (clpi2)
                barangayRow_CLPI.append (health)

                #calculate Nutrition Index
                count = 0
                if row[154] == None or row[156] == None or not row [154] or not row[156]:
                    clpi3 = 0
                    numnulls +=1
                    nutrition = 0
                else:
                    childmaln = float(row[154])
                    clpidem = float (row[156])
                    if clpidem == 0:
                        clpi3 = 0
                        numnulls +=1
                    else:
                        clpi3 = (childmaln/clpidem)*100
                        if clpi3 >100 or clpi3<0:
                            clpi3 = 0
                        else:
                            count +=1
                    nutrition = round(clpi3,2)

                barangayRow_Raw.append (clpi3)
                barangayRow_CLPI.append (nutrition)

                #calculate Access to Ammenities Index
                #this measure is reversed in logic
                #it is a positive measure, how many have access to rather than how many do not have access to
                #so need to reverse it as well in the code

                #in all of these, if the denominator is null or otherwise incorrect, can revert to numHouseholds?
                count = 0
                if row[157] == None or row[194] == None or not row [157] or not row[194]:
                    clpi4 = 0
                    numnulls +=1
                else:
                     hhPotableWater = float(row[157])
                     clpidem = float (row[194])
                     if clpidem == 0:
                        clpi4 = 0
                        numnulls +=1
                     else:
                        clpi4 = 100-((hhPotableWater/clpidem)*100)
                        if clpi4 > 100 or clpi4 <0:
                            clpi4 =0
                        else:
                            count +=1

                if row[159]==None or row[161]==None or not row [159] or not row[161]:
                    clpi5 = 0
                    numnulls +=1
                else:
                    hhSanitToilet = float(row[159])
                    clpidem2 = float (row[161])
                    if clpidem2 == 0:
                        clpi5 = 0
                        numnulls +=1
                    else:
                        clpi5 = 100-((hhSanitToilet/clpidem2)*100)
                        count +=1
                        if clpi5 > 100 or clpi5 < 100:
                            clpi5 = 0
                        else:
                            count +=1
                            
                if count == 0:
                    access = 0
                else:
                    access = round(((clpi4 + clpi5)/count), 2)
              
                barangayRow_Raw.append (clpi4)
                barangayRow_Raw.append (clpi5)
                barangayRow_CLPI.append (access)


                #calculate Shelter Index
                count = 0
                if row[163] == None or row[165] == None or not row [163] or not row[165]:
                    clpi6 = 0
                    numnulls +=1
                else:
                    hhSquatting = float(row[163])
                    clpidem = float (row[165])
                    if clpidem == 0:
                        clpi6 = 0
                        numnulls +=1
                    else:
                        clpi6 = (hhSquatting/clpidem)*100
                        if clpi6 > 100 or clpi6 < 0:
                            clpi6 = 0
                        else:
                            count +=1

                if row[167] == None or row[169] == None or not row [167] or not row[169]:
                    clpi7 = 0
                    numnulls +=1
                else:
                    hhMakeshift = float(row[167])
                    clpidem2 = float (row[169])
                    if clpidem2 == 0:
                        clpi7 = 0
                        numnulls +=1
                    else:
                        clpi7 = (hhMakeshift/clpidem2)*100
                        if clpi7 > 100 or clpi7 < 0:
                            clpi7 = 0
                        else:
                            count +=1

                if row[171]==None or row[173]== None or not row [171] or not row[173]:
                    clpi8 = 0
                    numnulls +=1
                else:
                    hhVictimCrime = float(row[171])
                    clpidem3 = float (row[173])
                    if clpidem3 == 0:
                        clpi8 = 0
                        numnulls +=1
                    else:
                        clpi8 = (hhVictimCrime/clpidem3)*100
                        if clpi8 > 100 or clpi8 < 0:
                            clpi8 = 0
                        else:
                            count +=1

                if count == 0:
                    shelter = 0
                else:
                    shelter = round((clpi6 + clpi7 + clpi8)/count, 2)
               
                barangayRow_Raw.append (clpi6)
                barangayRow_Raw.append (clpi7)
                barangayRow_Raw.append (clpi8)
                barangayRow_CLPI.append (shelter)


                #Income Index
                # count = 0
                # if row[175] == None or row[177] == None or not row [175] or not row[177]:
                    # clpi9 = 0
                    # numnulls +=1
                # else:
                    # hhIncomePovThresh = float(row[175])
                    # clpidem = float (row[177])
                    # if clpidem == 0:
                        # clpi9 = 0
                        # numnulls +=1
                    # else:
                        # clpi9 = (hhIncomePovThresh/clpidem)*100
                        # if clpi9 > 100 or clpi9 < 0:
                            # clpi9 = 0
                        # else:
                            # count +=1

                # if row[179] == None or row[181] == None or not row [179] or not row[181]:
                    # clpi10 = 0
                    # numnulls +=1
                # else:
                    # hhIncomeFoodThresh = float(row[179])
                    # clpidem2 = float (row[181])
                    # if clpidem2 == 0:
                        # clpi10 = 0
                        # numnulls +=1
                    # else:
                        # clpi10 = (hhIncomeFoodThresh/clpidem2)*100
                        # if clpi10 > 100 or clpi10 < 0:
                            # clpi10 = 0
                        # else:
                            # count +=1

                # if row[183]==None or row[185]== None or not row [183] or not row[185]:
                    # clpi11 = 0
                    # numnulls +=1
                # else:
                    # hhEatLessThree = float(row[183])
                    # clpidem3 = float (row[185])
                    # if clpidem3 == 0:
                        # clpi11 = 0
                        # numnulls +=1
                    # else:
                        # clpi11 = (hhEatLessThree/clpidem3)*100
                        # if clpi11 > 100 or clpi11 <0:
                            # clpi11 = 0
                        # else:
                            # count +=1

                # if count == 0:
                    # income = 0
                # else:
                    # income = round((clpi9 + clpi10 + clpi11)/count, 2)
        
                # barangayRow_Raw.append (clpi9)
                # barangayRow_Raw.append (clpi10)
                # barangayRow_Raw.append (clpi11)
                # barangayRow_CLPI.append (income)


                 #Education Index
                count = 0
                if row[186] == None or row[188] == None or not row [186] or not row[188]:
                    clpi12 = 0
                    numnulls +=1
                else:
                    child612NotSchool = float(row[186])
                    clpidem = float (row[188])
                     #check for 0 in denominator, so as to avoid dividing by 0
                    if clpidem == 0:
                        clpi12 = 0
                        numnulls +=1
                    else:
                        clpi12 = (child612NotSchool/clpidem)*100
                        if clpi12 > 100 or clpi12 < 0:
                            clpi12 = 0
                        else:
                            count +=1

                if row[189] == None or row[202] == None or not row [189] or not row[202]:
                    clpi13 = 0
                    numnulls +=1
                else:
                    child1316NotSchool = float(row[189])
                    clpidem2 = float (row[202])
                    #check for 0 in denominator, so as to avoid dividing by 0
                    if clpidem2 == 0:
                        clpi13 = 0
                        numnulls +=1
                    else:
                        clpi13= (child1316NotSchool/clpidem2)*100
                        if clpi13 > 100 or clpi13 < 0:
                            clpi13= 0 
                        else:
                            count +=1

                if count == 0:
                    education = 0
                else:
                    education = round((clpi12 + clpi13)/count, 2)
             
                barangayRow_Raw.append (clpi12)
                barangayRow_Raw.append (clpi13)
                barangayRow_CLPI.append (education)


                #Labor Index
                # count = 0
                # if row[190] == None or row[192] == None or not row [190] or not row[192]:
                    # clpi14 = 0
                    # numnulls +=1
                    # labor = 0
                # else:
                    # laborersNotWorking = float(row[190])
                    # clpidem = float (row[192])
                    # if clpidem == 0:
                        # clpi14 = 0
                        # numnulls +=1
                    # else:
                        # clpi14 = (laborersNotWorking/clpidem)*100
                        # count +=1
                    # if clpi14 >100 or clpi14 < 0:
                        # clpi14 = 0
                    # labor = round(clpi14, 2)

                # barangayRow_Raw.append (clpi14)
                # barangayRow_CLPI.append (labor)

                # composite = round(((health + nutrition + access + shelter +labor +education + income)/7), 2)

                # barangayRow_CLPI.append (composite)
                barangayRow_CLPI.append (numnulls)
                barangayRow_Raw.append (numnulls)
                
                totalrows +=1
                #clpiTuple is a List that holds the computed indexes for all barangay in the excel file
                #rawTuple is a list that holds the raw collected measures for each barangay
                clpiTuple.append (barangayRow_CLPI)
                rawTuple.append (barangayRow_Raw)
        
        print "barangay processed", totalrows
        print "CLPI data saved"
        
        #save raw and processed tuples as files
        tempStrng = PIMSFileLocation.rpartition("/") #need to cut off last file so up to and including the last "\"
        prjctFolder = tempStrng [0] + tempStrng[1]
        
        print "folder info in CLPImake function: " + prjctFolder
        rawFile = prjctFolder + "raw_PIMS.csv"
        clpiFile = prjctFolder + "clpi_PIMS.csv"
        with open(clpiFile, 'wb') as f:
            writer = csv.writer(f)
            writer.writerows(clpiTuple)
        with open(rawFile, 'wb') as f:
            writer = csv.writer(f)
            writer.writerows(rawTuple)
    return

    
def joinCSV (AreaOfInterest, crs, layerLocation):
    #needs : define CRS of layers 
    
    shpFile = layerLocation + "\\barangays_PH.shp"
    print "adding CLPI Barangay data as layer: " + shpFile
    
    barangayLyr =QgsVectorLayer(shpFile, 'CLPI_Barangays' , "ogr")
    barangayLyr.isValid()
    filter = "MuniCiti_1 = '"+AreaOfInterest+"'"
    barangayLyr.setSubsetString( filter )
    
    #load PIMS data raw and clpi
    shpFile = layerLocation + "\\clpi_PIMS.csv"    
    PIMSLyr =QgsVectorLayer(shpFile, 'clpi_PIMS' , "ogr")
    PIMSLyr.isValid()

    shpFile = layerLocation + "\\raw_PIMS.csv"
    rawLyr = QgsVectorLayer(shpFile, 'raw_PIMS' , "ogr")
    rawLyr.isValid()
    
    QgsMapLayerRegistry.instance().addMapLayers([barangayLyr,PIMSLyr, rawLyr], True)

    #Commands to join clpi csv file to Barangay
    info = QgsVectorJoinInfo()
    info.joinLayerId = PIMSLyr.id()

    info.joinFieldName = "Brgy_PSGC"
    info.targetFieldName = "Brgy_PSGC"
    info.memoryCache = True
    barangayLyr.addJoin(info)

    #set extent for map - not sure works
    canvas = iface.mapCanvas()
    extent = barangayLyr.extent()
    canvas.setExtent(extent)
    canvas.refresh()

    #symbolize layer (barangay) by Data Quality measure of number of nulls in the 10 CLPI (w/o income, labor) 
    field = "clpi_PIMS_numNulls"
    ranges =[]
    dataQualityRanges = (
        ("Few Nulls (0-1)",0,1, "white"),
        ("Low (2-3)", 2, 3, "yellow"),
        ("Medium (4-6)",4, 6, "orange"),
        ("High (7-10)", 7, 10, "red"))
        
    for label, lower, upper, color in dataQualityRanges:
        sym = QgsSymbolV2.defaultSymbol (barangayLyr.geometryType())
        sym.setColor(QColor(color))
        rng = QgsRendererRangeV2(lower, upper, sym, label)
        ranges.append(rng)
        
    renderer = QgsGraduatedSymbolRendererV2 (field, ranges)
    barangayLyr.setRendererV2(renderer)

    #show labels for barangay in relevant municipality
    label = QgsPalLayerSettings()
    label.readFromLayer(barangayLyr)
    label.enabled = True
    label.fieldName = "Barangay"
    label.placement = QgsPalLayerSettings.AroundPoint
    label.setDataDefinedProperty(QgsPalLayerSettings.Size,True, True, '8','')

    label.writeToLayer(barangayLyr)

    QgsMapLayerRegistry.instance().addMapLayer (barangayLyr)
    iface.setActiveLayer(barangayLyr)
    
    #zoom to layer (barangay)
    iface.zoomToActiveLayer()
    
    return
    
def validatedDefaultSymbol(geometryType ):
    symbol = QgsSymbolV2.defaultSymbol(geometryType )
    if symbol is None:
        if geometryType == QGis.Point:
            symbol = QgsMarkerSymbolV2()
        elif geometryType == QGis.Line:
            symbol =  QgsLineSymbolV2 ()
        elif geometryType == QGis.Polygon:
            symbol = QgsFillSymbolV2 ()
    return symbol
    
def applyGraduatedSymbologyStandardMode( layer, targetField, classes, mode):
    labelFormat = QgsRendererRangeV2LabelFormat()
    labelFormat.setFormat("%1% - %2%")
    #labelFormat.setPrecision(2)
    
    symbol = validatedDefaultSymbol( layer.geometryType() )
    colorRamp = QgsVectorGradientColorRampV2.create({'color1':'255,255,178', 'color2':'189,0,38','stops':'0.25;255,127,0:0.50;255,127,0:0.75;255,127,0'})
    renderer = QgsGraduatedSymbolRendererV2.createRenderer( layer, targetField, classes, mode, symbol, colorRamp)
    renderer.setLabelFormat(labelFormat)
    #renderer.setSizeScaleField("LABELRANK")
    layer.setRendererV2( renderer )
    return

def symbolizeMaps(AreaOfInterest):
    # OLD INDICATORS 7 plus 1
    # indicators = (
        # "health","nutrition","access","shelter","income","education", "labor", "composite")
        
    #NEW INDICATORS 5
    indicators = (
        "health","nutrition","access","shelter","education")


    modes = { 
              QgsGraduatedSymbolRendererV2.Jenks         : "Natural Breaks (Jenks)"
            } 


    layer=None
    for lyr in QgsMapLayerRegistry.instance().mapLayers().values():
        if lyr.name() == "CLPI_Barangays":
            layer = lyr
            #for each indicator make a copy of the original (and joined) layer
            for indicator in indicators:
                print "making " + indicator + " layer"
                iface.setActiveLayer(layer)
                iface.zoomToActiveLayer()
                iface.actionDuplicateLayer().trigger()
                layer.setLayerName(indicator)
                
                render = QgsMapRenderer()                
                vLayer = layer
                targetField = 'clpi_PIMS_' + indicator
                renderer = QgsGraduatedSymbolRendererV2 (targetField)
                vLayer.setRendererV2(renderer)

                classes = 3
                for mode in modes.keys():
                    if vLayer.isValid():
                        applyGraduatedSymbologyStandardMode(vLayer, targetField, classes, mode)
                        QgsMapLayerRegistry.instance().addMapLayers( [vLayer] ) 
                        vLayer.triggerRepaint()
                iface.mapCanvas().refresh()
    
    #I think this sets the last lyr as the active one
    iface.setActiveLayer(lyr)
    
    #turn off all layers (on)
    legend = iface.legendInterface()
    layers = iface.legendInterface().layers()
    for layer in layers:
        legend.isLayerVisible(layer)
        legend.setLayerVisible(layer, True)
    
  
    
    iface.mapCanvas().refresh()
    
    
    return




def loadProject(muniNumber, layerLocation):
    #currently non-functional re CRS
    # Get the project instance
    project = QgsProject.instance()
    
    #save project immediately?  Could get path then...
    
    my_crs = QgsCoordinateReferenceSystem(32651,QgsCoordinateReferenceSystem.EpsgCrsId)
    print my_crs
    iface.mapCanvas().mapSettings().setDestinationCrs(my_crs)
    
    # Set the background color to light sky blue (ocean blue).
    # is not permanent, needs to be set in project somehow
    
    oceanColor = QColor.fromRgb(135,206,235);
    iface.mapCanvas().setCanvasColor(oceanColor)
    iface.mapCanvas().enableAntiAliasing(True)
    
    
    
    #load Municipal Layer, set color to grey, turn on municipal name labels
    shpFileTuple = layerLocation.partition(':')
    shpFile = shpFileTuple [2] + "\\municipalities_PH.shp"
    shpFile = shpFile.replace("\\","/")
    print "shpFile for muni is: " + shpFile
    muniLyr = QgsVectorLayer(shpFile,'Municipalities' , "ogr")
    #muniLyr = QgsVectorLayer('/Users/student/Documents/QGIS/MapAtlases_PH/MuniCities.shp','Municipalities' , "ogr")
    muniLyr.isValid()
    
    #set to color grey
    symbols = muniLyr.rendererV2().symbols()
    sym = symbols[0]
    sym.setColor(QColor.fromRgb(128,128,128))
    muniLyr.triggerRepaint()
    
    #show labels of Municipalities
    label = QgsPalLayerSettings()
    label.readFromLayer(muniLyr)
    label.enabled = True
    label.fieldName = "muniCities"
    label.placement = QgsPalLayerSettings.AroundPoint
    label.setDataDefinedProperty(QgsPalLayerSettings.Size,True, True, '12','')

    label.bufferDraw= True
    label.bufferColor= QColor("white")
    label.bufferSize = 1

    label.writeToLayer(muniLyr)
    
    
    #load Barangay Layer, filter to relevant area, set color to grey, and labels on
    shpFile = shpFileTuple [2] + "\\barangays_PH.shp"
    shpFile = shpFile.replace("\\","/")
    print "shpFile for muni is: " + shpFile
    barangayLyr =QgsVectorLayer(shpFile,'Barangays_in_Muni' , "ogr")
    #barangayLyr =QgsVectorLayer('/Users/student/Documents/QGIS/MapAtlases_PH/Barangays.shp','Barangays_in_Muni' , "ogr")
    barangayLyr.isValid()
    filter = "MuniCiti_1 = '"+muniNumber+"'"
    barangayLyr.setSubsetString( filter )
    
    #set to color grey
    symbols = barangayLyr.rendererV2().symbols()
    sym = symbols[0]
    sym.setColor(QColor.fromRgb(128,128,128))
    
    #show labels for barangay in relevant municipality
    label = QgsPalLayerSettings()
    label.readFromLayer(barangayLyr)
    label.enabled = True
    label.fieldName = "Barangay"
    label.placement = QgsPalLayerSettings.AroundPoint
    label.setDataDefinedProperty(QgsPalLayerSettings.Size,True, True, '8','')
    label.writeToLayer(barangayLyr)
    
    #add layers to canvas
    QgsMapLayerRegistry.instance().addMapLayers([barangayLyr, muniLyr], True)
    barangayLyr.triggerRepaint()
    
    #set mapExtent to municipal area
    extent = barangayLyr.extent()
    iface.mapCanvas().mapSettings().setExtent(extent)
    
    iface.mapCanvas().show()
    iface.mapCanvas().refresh()
    return extent
    
def makeCompositions(barangayExtent):
    theme = "composite"
    templateName = "/Users/student/.qgis2/composer_templates/" + theme +".qpt"
    myTemplateFile = file (templateName, 'rt')
    myTemplateContent = myTemplateFile.read()
    myTemplateFile.close()
    myDocument = QDomDocument()
    myDocument.setContent(myTemplateContent, False)
    view = iface.createNewComposer()
    view.composition().loadFromTemplate(myDocument)
    print "loaded template"
    
    mapRenderer = iface.mapCanvas().mapSettings()
    c = QgsComposition(mapRenderer)
    c.setPlotStyle(QgsComposition.Print)
    #view = iface.createNewComposer()
   

    #add map
    rect = QgsRectangle(barangayExtent)
    x, y = 5, 15
    #w, h = c.paperWidth(), c.paperHeight()
    w, h = 175, 175
    composerMap = QgsComposerMap(c,x,y,w,h)
    composerMap.setNewExtent(rect)
    composerMap.updateItem()
    c.addComposerMap (composerMap)
    c.refreshItems()
    view.setComposition(c)
    
    # find items and items prop widget
    win = view.composerWindow()
    items_widget = win.findChildren(QDockWidget, 'ItemsDock')[0]

    items_widget_prop = win.findChildren(QDockWidget, 'ItemDock')[0]
    items_widget_prop.show()

    # set items model
    items_list_widget = items_widget.findChildren(QTreeView,'')[0]
    items_model = c.itemsModel()
    items_list_widget.setModel(items_model)

    QObject.connect( items_list_widget.selectionModel(), SIGNAL("currentChanged( QModelIndex, QModelIndex)"), c.itemsModel(),SLOT("setSelected( QModelIndex )"))
    iface.messageBar().pushMessage("KIM","Help me Kim", QgsMessageBar.WARNING, 2)
    
    #prep for printing
    dpi = c.printResolution()
    dpmm = dpi / 25.4
    width = int(dpmm * c.paperWidth())
    height = int(dpmm * c.paperHeight())

    # create output image and initialize it
    image = QImage(QSize(width, height), QImage.Format_ARGB32)
    image.setDotsPerMeterX(dpmm * 1000)
    image.setDotsPerMeterY(dpmm * 1000)
    image.fill(0)

    # render the composition
    imagePainter = QPainter(image)
    sourceArea = QRectF(0, 0, c.paperWidth(), c.paperHeight())
    targetArea = QRectF(0, 0, width, height)
    c.render(imagePainter, 0)
    #right here it crashes but does produce the Composer item.  If it continues then it removes it.
    print "got to the weird 0 in imagePainter"
    
    #imagePainter.end()
    print "about to save map as png"
    mapFileName = "/Users/student/Documents/QGIS/MapAtlases_PH/output.png"
    image.save(mapFileName, "png")
    return
   
def loadTemplate(barangayExtent):
#   for theme in indicators:
    theme = "composite"
    templateName = "/Users/student/.qgis2/composer_templates/" + theme +".qpt"
    myTemplateFile = file (templateName, 'rt')
    myTemplateContent = myTemplateFile.read()
    myTemplateFile.close()
    myDocument = QDomDocument()
    myDocument.setContent(myTemplateContent, False)
    view = iface.createNewComposer()
    view.composition().loadFromTemplate(myDocument)
    print "loaded template"
   
    mapRenderer = iface.mapCanvas().mapSettings()
    c = QgsComposition(mapRenderer)
    #newcomp.setComposition (c)
    
    
    #add mapItem
    #add map
    rect = QgsRectangle(barangayExtent)
    x, y = 5, 15
    #w, h = c.paperWidth(), c.paperHeight()
    w, h = 175, 175
    composerMap = QgsComposerMap(c,x,y,w,h)
    composerMap.setNewExtent(rect)
    composerMap.updateItem()
    c.addComposerMap (composerMap)
    c.refreshItems()
    #newcomp.setComposition(composition)
    view.setComposition(c)

    

    return
    
    
class Atlas:
    """QGIS Plugin Implementation."""

    def __init__(self, iface):
        """Constructor.

        :param iface: An interface instance that will be passed to this class
            which provides the hook by which you can manipulate the QGIS
            application at run time.
        :type iface: QgsInterface
        """
        # Save reference to the QGIS interface
        self.iface = iface
        # initialize plugin directory
        self.plugin_dir = os.path.dirname(__file__)
        # initialize locale
        locale = QSettings().value('locale/userLocale')[0:2]
        locale_path = os.path.join(
            self.plugin_dir,
            'i18n',
            'Atlas_{}.qm'.format(locale))

        if os.path.exists(locale_path):
            self.translator = QTranslator()
            self.translator.load(locale_path)

            if qVersion() > '4.3.3':
                QCoreApplication.installTranslator(self.translator)

        # Create the dialog (after translation) and keep reference
        self.dlg = AtlasDialog()

        # Declare instance attributes
        self.actions = []
        self.menu = self.tr(u'&Atlas')
        # TODO: We are going to let the user set this up in a future iteration
        self.toolbar = self.iface.addToolBar(u'Atlas')
        self.toolbar.setObjectName(u'Atlas')
        
        self.dlg.lineEdit.clear()
        self.dlg.pushButton.clicked.connect(self.select_input_file)
        
        self.dlg.lineEdit_2.clear()
        self.dlg.pushButton_2.clicked.connect(self.select_output_folder)
        
    # noinspection PyMethodMayBeStatic
    def tr(self, message):
        """Get the translation for a string using Qt translation API.

        We implement this ourselves since we do not inherit QObject.

        :param message: String for translation.
        :type message: str, QString

        :returns: Translated version of message.
        :rtype: QString
        """
        # noinspection PyTypeChecker,PyArgumentList,PyCallByClass
        return QCoreApplication.translate('Atlas', message)


    def add_action(
        self,
        icon_path,
        text,
        callback,
        enabled_flag=True,
        add_to_menu=True,
        add_to_toolbar=True,
        status_tip=None,
        whats_this=None,
        parent=None):
        """Add a toolbar icon to the toolbar.

        :param icon_path: Path to the icon for this action. Can be a resource
            path (e.g. ':/plugins/foo/bar.png') or a normal file system path.
        :type icon_path: str

        :param text: Text that should be shown in menu items for this action.
        :type text: str

        :param callback: Function to be called when the action is triggered.
        :type callback: function

        :param enabled_flag: A flag indicating if the action should be enabled
            by default. Defaults to True.
        :type enabled_flag: bool

        :param add_to_menu: Flag indicating whether the action should also
            be added to the menu. Defaults to True.
        :type add_to_menu: bool

        :param add_to_toolbar: Flag indicating whether the action should also
            be added to the toolbar. Defaults to True.
        :type add_to_toolbar: bool

        :param status_tip: Optional text to show in a popup when mouse pointer
            hovers over the action.
        :type status_tip: str

        :param parent: Parent widget for the new action. Defaults None.
        :type parent: QWidget

        :param whats_this: Optional text to show in the status bar when the
            mouse pointer hovers over the action.

        :returns: The action that was created. Note that the action is also
            added to self.actions list.
        :rtype: QAction
        """

        icon = QIcon(icon_path)
        action = QAction(icon, text, parent)
        action.triggered.connect(callback)
        action.setEnabled(enabled_flag)

        if status_tip is not None:
            action.setStatusTip(status_tip)

        if whats_this is not None:
            action.setWhatsThis(whats_this)

        if add_to_toolbar:
            self.toolbar.addAction(action)

        if add_to_menu:
            self.iface.addPluginToMenu(
                self.menu,
                action)

        self.actions.append(action)

        return action

    def initGui(self):
        """Create the menu entries and toolbar icons inside the QGIS GUI."""

        icon_path = ':/plugins/Atlas/icon.png'
        self.add_action(
            icon_path,
            text=self.tr(u'Create Municipal Atlases'),
            callback=self.run,
            parent=self.iface.mainWindow())


    def unload(self):
        """Removes the plugin menu item and icon from QGIS GUI."""
        for action in self.actions:
            self.iface.removePluginMenu(
                self.tr(u'&Atlas'),
                action)
            self.iface.removeToolBarIcon(action)
        # remove the toolbar
        del self.toolbar

    def select_input_file(self):
        filename = QFileDialog.getOpenFileName (self.dlg, "Open File ","",'*.csv')
        self.dlg.lineEdit.setText(filename)
        
        #now enable municipalityComboBox based on the municipalities in the inputfile
        #here also the CLPI is created
       
        createCLPI (filename)
        self.dlg.comboBox_2.addItems(sorted(muniDict.values()))
        self.dlg.comboBox_2.setEnabled(True)
        
    def select_output_folder(self):
        #foldername = QFileDialog.getSaveFileName (self.dlg, "Select Output File", "",'*.qgs')
        foldername = QFileDialog.getExistingDirectory (self.dlg, "Select Project Folder", "")
        self.dlg.lineEdit_2.setText(foldername)
        
        
        
        
    def run(self):
        """Run method that performs all the real work"""
      
        # show the dialog
        self.dlg.show()
        # Run the dialog event loop
        result = self.dlg.exec_()
        # See if OK was pressed
        if result:
            # Do something useful here - delete the line containing pass and
            # substitute with your code.
            #pass
            #put code here
            filename = self.dlg.lineEdit.text()
            muniName = self.dlg.comboBox_2.currentText()
            prjctFolder = self.dlg.lineEdit_2.text()
            
 
            print "muni Name is: " + muniName
            print "project folder is: " + prjctFolder
            
            #acquire muniPSGC from MuniName
            for mNum, mName in muniDict.items():
                if muniName.upper() == mName.upper():
                    muniNumber = mNum
                    break
            print "muni number is: " + muniNumber
 
            crs = QgsCoordinateReferenceSystem("32651") #set CRS to WGS84/UTM51N doesn't work

            barangayExtent = loadProject(muniNumber, prjctFolder)
            print "the barangayExtent is: ", barangayExtent
            
            joinCSV (muniNumber, crs, prjctFolder)
            symbolizeMaps(muniNumber)
            
            #save project
    
            prjctFileName = prjctFolder + "/map" + muniNumber + ".qgs"
            print "saving temporary project as " + prjctFolder + "\\map" + muniNumber + ".qgs"
            f = QFileInfo (prjctFileName)
            p = QgsProject.instance()
            p.write(f)
            
            #renaming layers and making visible to TOC and user
            legend = iface.legendInterface()
            layers = iface.legendInterface().layers()
            for layer in layers:
                lname = layer.name()
                if lname == "composite":
                    legend.isLayerVisible(layer)
                    legend.setLayerVisible(layer, True)
                elif lname == "Municipalities":
                    legend.isLayerVisible(layer)
                    legend.setLayerVisible(layer, True)
                elif lname == "Barangays_in_Muni":
                    legend.isLayerVisible(layer)
                    legend.setLayerVisible(layer, True)
                else:
                    legend.isLayerVisible(layer)
                    legend.setLayerVisible(layer, False)
                
                if lname.endswith("copy"):
                    new_name = lname.rstrip("copy")
                    layer.setLayerName(new_name)
                
                if lname.startswith("CLPI_Barangays"):
                    new_name = "Data_Quality"
                    layer.setLayerName(new_name)
            
            #loadTemplate(barangayExtent)

            #makeCompositions(barangayExtent)

    